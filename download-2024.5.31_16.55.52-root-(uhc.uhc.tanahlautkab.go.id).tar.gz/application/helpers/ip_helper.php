<?php

function ip()
{
    return 'http://103.165.243.97/';
    // return 'http://192.168.100.100/ptsp/';
}



function ip_embed()
{
    return 'https://103.165.243.97/';
    // return 'http://192.168.100.100/ptsp/';
}