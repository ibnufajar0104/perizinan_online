<div class="topnav">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

            <div class="collapse navbar-collapse" id="topnav-menu-content">
                <ul class="navbar-nav">

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="<?= site_url('permohonan') ?>"
                            id="topnav-dashboard" role="button">
                            <i data-feather="file-text"></i><span data-key="t-dashboard">Permohonan</span>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="<?= site_url('permohonan/riwayat') ?>"
                            id="topnav-dashboard" role="button">
                            <i data-feather="clock"></i><span data-key="t-dashboard">Riwayat Permohonan</span>
                        </a>
                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>