<?php

function ip()
{
    return 'http://172.16.36.105/ptsp/';
    // return 'http://192.168.100.100/ptsp/';
}